package vn.lichviet.app.widget;

import android.widget.RemoteViews;
import java.util.Calendar;
import vn.lichviet.app.R;

public class WidgetMedium extends WidgetBase {
    int layout() { return R.layout.widget_medium; }
    void fill(RemoteViews v, Info d) {
        v.setTextViewText(R.id.tv_greet, d.greet);
        v.setTextViewText(R.id.tv_sig, d.sig);
        v.setViewVisibility(R.id.tv_sig, d.sig.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
        v.setTextViewText(R.id.tv_solar, WD[d.cal.get(Calendar.DAY_OF_WEEK) - 1] + ", " + d.cal.get(Calendar.DAY_OF_MONTH) + " tháng " + (d.cal.get(Calendar.MONTH) + 1));
        v.setTextViewText(R.id.tv_lunar, "Âm lịch " + lunarShort(d));
        v.setTextViewText(R.id.tv_lunar_sub, "Năm " + Lunar.yearName(d.ly));
        v.setTextViewText(R.id.tv_wx, d.emoji + " " + d.temp);
        v.setTextViewText(R.id.tv_wx_desc, d.city + " · " + d.desc);
        style(v, d, new int[]{R.id.clock, R.id.tv_greet, R.id.tv_wx}, new int[]{R.id.tv_solar, R.id.tv_lunar_sub, R.id.tv_wx_desc}, new int[]{R.id.tv_lunar, R.id.tv_sig});
    }
}
