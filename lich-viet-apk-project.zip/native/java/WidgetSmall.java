package vn.lichviet.app.widget;

import android.widget.RemoteViews;
import java.util.Calendar;
import vn.lichviet.app.R;

public class WidgetSmall extends WidgetBase {
    int layout() { return R.layout.widget_small; }
    void fill(RemoteViews v, Info d) {
        v.setTextViewText(R.id.tv_solar, WD_S[d.cal.get(Calendar.DAY_OF_WEEK) - 1] + " · " + d.cal.get(Calendar.DAY_OF_MONTH) + "/" + (d.cal.get(Calendar.MONTH) + 1) + " · " + d.temp);
        v.setTextViewText(R.id.tv_lunar, "Âm " + lunarShort(d));
        v.setTextViewText(R.id.tv_greet, d.greet);
        style(v, d, new int[]{R.id.clock, R.id.tv_greet}, new int[]{R.id.tv_solar}, new int[]{R.id.tv_lunar});
    }
}
