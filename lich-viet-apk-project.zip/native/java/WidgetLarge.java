package vn.lichviet.app.widget;

import android.widget.RemoteViews;
import java.util.Calendar;
import vn.lichviet.app.R;

public class WidgetLarge extends WidgetBase {
    int layout() { return R.layout.widget_large; }
    void fill(RemoteViews v, Info d) {
        v.setTextViewText(R.id.tv_greet, d.greet);
        v.setTextViewText(R.id.tv_sig, d.sig);
        v.setViewVisibility(R.id.tv_sig, d.sig.isEmpty() ? android.view.View.GONE : android.view.View.VISIBLE);
        v.setTextViewText(R.id.tv_solar, WD[d.cal.get(Calendar.DAY_OF_WEEK) - 1] + ", " + d.cal.get(Calendar.DAY_OF_MONTH) + "/" + (d.cal.get(Calendar.MONTH) + 1) + "/" + d.cal.get(Calendar.YEAR));
        v.setTextViewText(R.id.tv_big_lunar, String.valueOf(d.ld));
        v.setTextViewText(R.id.tv_lunar_sub, "Tháng " + d.lm + (d.leap == 1 ? " nhuận" : "") + " · Năm " + Lunar.yearName(d.ly));
        v.setTextViewText(R.id.tv_day_cc, "Ngày " + Lunar.dayName(d.jdn));
        v.setTextViewText(R.id.tv_wx, d.emoji + " " + d.temp);
        v.setTextViewText(R.id.tv_wx_desc, d.city + " · " + d.desc);
        v.setTextViewText(R.id.tv_wx_range, d.range);
        v.setTextViewText(R.id.tv_next, "🌕 " + d.next);
        style(v, d, new int[]{R.id.clock, R.id.tv_greet, R.id.tv_wx, R.id.tv_lunar_sub},
            new int[]{R.id.tv_solar, R.id.tv_wx_desc, R.id.tv_day_cc, R.id.tv_wx_range, R.id.tv_cap},
            new int[]{R.id.tv_big_lunar, R.id.tv_sig, R.id.tv_next});
        v.setInt(R.id.div, "setBackgroundColor", COL[d.style][3]);
        v.setInt(R.id.tv_next, "setBackgroundResource", PILL[d.style]);
    }
}
